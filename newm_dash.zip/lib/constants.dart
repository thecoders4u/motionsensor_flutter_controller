import 'package:flutter/material.dart';

const primaryColor = Colors.black;
const secondaryColor = Colors.white;
const bgColor = Colors.black;

const defaultPadding = 16.0;
