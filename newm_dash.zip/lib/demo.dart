import 'package:flutter/material.dart';

class Demo extends MaterialPageRoute<void>{
  Demo({required WidgetBuilder builder}) : super(
      builder: builder);
}