import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';

import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'components/header.dart';
import 'package:admin/constants.dart';

class FalseAlert extends StatefulWidget {
  const FalseAlert({Key? key}) : super(key: key);

  @override
  State<FalseAlert> createState() => _FalseAlertState();
}

class _FalseAlertState extends State<FalseAlert> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "False Alerts",
          style: TextStyle(
            color: Colors.red,
          ),
        ),
        backgroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 5),
        child: SafeArea(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 5),
                child: Header(),
              ),
              const SizedBox(height: 5),
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    margin: const EdgeInsets.all(10),
                    padding: const EdgeInsets.all(defaultPadding),
                    decoration: const BoxDecoration(
                      color: secondaryColor,
                      borderRadius: BorderRadius.all(Radius.circular(10)),
                    ),
                    child: SizedBox(
                        width: MediaQuery.of(context).size.width,
                        child: Column(
                          children: <Widget>[
                            Text("False Alerts"),
                            SingleChildScrollView(
                                scrollDirection: Axis.horizontal,
                                child: DataTable(
                                  columns: [
                                    DataColumn(
                                      label: Text('No'),
                                    ),
                                    DataColumn(
                                      label: Text('Date'),
                                    ),
                                    DataColumn(
                                      label: Text('Type'),
                                    ),
                                    DataColumn(label: Text('Details')),
                                  ],
                                  rows: [
                                    DataRow(cells: [
                                      DataCell(Text("1")),
                                      DataCell(Text("1/01/2023")),
                                      DataCell(Text("Motion Detection")),
                                      DataCell(ElevatedButton(
                                          style: ButtonStyle(

                                              backgroundColor: MaterialStateProperty.all(Colors.red),
                                              shape: MaterialStateProperty.all<
                                                      RoundedRectangleBorder>(
                                                  RoundedRectangleBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              18.0),
                                                      side: BorderSide(
                                                          color:
                                                              Colors.white)))),
                                          onPressed: () async {},
                                          child: Padding(
                                            padding: const EdgeInsets.all(10.0),
                                            child: Icon(
                                              Icons.photo_library_sharp
                                            ),
                                          )))
                                    ])
                                  ],
                                ))
                          ],
                        )),
                  )
                ],
              ),
            ],
          ), //Entire app is an a column so therefore inside is a series of rows
        ),
      ),
    );
  }
}
