import 'package:admin/allclasses.dart';
import 'package:admin/constants.dart';
import 'package:admin/databaseconnection.dart';
import 'package:admin/responsive.dart';
import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import '../../databaseconnection.dart';
import 'components/header.dart';
import 'package:admin/firebase_options.dart';
import 'package:firebase_core/firebase_core.dart';
import 'components/monitordata.dart';

class MonitorScreen extends StatefulWidget {
  const MonitorScreen({Key? key}) : super(key: key);

  @override
  State<MonitorScreen> createState() => _MonitorScreenState();
}

class _MonitorScreenState extends State<MonitorScreen> {
  late DatabaseReference _databaseReference;
  @override
  initState() {
    // TODO: implement initState
    super.initState();
    initiateFirebase();
  }

  Future<void> initiateFirebase() async {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    ).whenComplete(() {
      print("completed");
      setState(() {
        _databaseReference = FirebaseDatabase.instance.ref("messages/2022");
      });
      _databaseReference.onValue.listen((DatabaseEvent event) {
        final data = event.snapshot.value;
        print(data);
      });
    });
  }

  String? _email;
  TextEditingController message = TextEditingController();
  bool auto = true;
  bool innerauto = true;
  bool motion = false;
  bool object = false;
  bool criminal = false;
  bool useSettings = false;

  int val = -1;
  int val2 = -1;
  Widget _returnAutomatic() {
    return Column(children: [
      Text('Use Your Current System Settings:'),
      ListTile(
        title: Text("Yes"),
        leading: Radio(
          groupValue: val2,
          value: 1,
          onChanged: (value) {
            setState(() {
              val2 = value as int;
              innerauto = true;
              useSettings = true;
            });
          },
          activeColor: Colors.red,
        ),
      ),
      ListTile(
        title: Text("No"),
        leading: Radio(
          groupValue: val2,
          value: 2,
          onChanged: (value) {
            setState(() {
              val2 = value as int;
              innerauto = false;
              useSettings = false;
            });
          },
          activeColor: Colors.red,
        ),
      ),
      Text(
          'Select Preferences for Securing Environment (the maximum is two preferences):'),
      ListTile(
        title: Text("Motion-Detection"),
        leading: Checkbox(
          value: motion,
          onChanged: (value) {
            setState(() {
              if (motion) {
                motion = false;
              } else {
                if (criminal && object) {
                  motion = false;
                } else {
                  motion = true;
                }
              }
            });
          },
          activeColor: Colors.red,
        ),
      ),
      ListTile(
        title: Text("Object-Detection"),
        leading: Checkbox(
          value: object,
          onChanged: (value) {
            setState(() {
              if (object) {
                object = false;
              } else {
                if (criminal && motion) {
                  object = false;
                } else {
                  object = true;
                }
              }
            });
          },
          activeColor: Colors.red,
        ),
      ),
      ListTile(
        title: Text("Criminal-Detection"),
        leading: Checkbox(
          value: criminal,
          onChanged: (value) {
            setState(() {
              if (criminal) {
                criminal = false;
              } else {
                if (motion && object) {
                  criminal = false;
                } else {
                  criminal = true;
                }
              }
            });
          },
          activeColor: Colors.red,
        ),
      ),
      ElevatedButton(
          style: ButtonStyle(
              backgroundColor: MaterialStateProperty.all(Colors.red),
              shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                  RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(18.0),
                      side: BorderSide(color: Colors.white)))),
          onPressed: () async {
            setState(() {
              Services.cameramessages['type'] = CameraMessages.automatic;
              Services.cameramessages['settings_mode'] = useSettings;
              Services.cameramessages['days'] = Services.currentsettings['active_days'];
              Services.cameramessages['camera_sensitivity'] = Services.currentsettings['camerasensitivity'];
              Services.cameramessages['start_time'] = Services.currentsettings['start_time'];
              Services.cameramessages['end_time'] = Services.currentsettings['end_time'];
              Services.cameramessages = Services.currentsettings['customer_id'];

            });
            await _databaseReference.set({
              "cameramessage": Services.cameramessages,
            }).whenComplete(() => print("success"));
          },
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: const Text('Start Automatically',
                style: TextStyle(color: Colors.white, fontSize: 16)),
          ))
    ]);
  }

  Widget _returnManual() {
    return ElevatedButton(
        style: ButtonStyle(
            backgroundColor: MaterialStateProperty.all(Colors.red),
            shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(18.0),
                    side: BorderSide(color: Colors.white)))),
        onPressed: () async {
          setState(() {
            Services.cameramessages['type'] = CameraMessages.remote;
            Services.cameramessages['settings_mode'] = useSettings;
            Services.cameramessages['days'] = Services.currentsettings['active_days'];
            Services.cameramessages['camera_sensitivity'] = Services.currentsettings['camerasensitivity'];
            Services.cameramessages['start_time'] = Services.currentsettings['start_time'];
            Services.cameramessages['end_time'] = Services.currentsettings['end_time'];
            Services.cameramessages = Services.currentsettings['customer_id'];
          });
        },
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: const Text('Start Monitoring',
              style: TextStyle(color: Colors.white, fontSize: 16)),
        ));
  }

  Widget _buildEmail() {
    return TextFormField(
      controller: message,
      decoration: InputDecoration(
        enabledBorder: UnderlineInputBorder(
          borderSide: BorderSide(color: Colors.blue),
        ),
        filled: true,
        icon: Icon(
          Icons.send,
          color: Colors.blue,
        ),
        hintText: 'Message',
        labelText: 'Msg',
        labelStyle: TextStyle(
          color: Colors.blue,
        ),
      ),
      keyboardType: TextInputType.emailAddress,
      onSaved: (String? value) {
        this._email = value;
        print('email=$_email');
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Monitor",
          style: TextStyle(
            color: Colors.red,
          ),
        ),
        backgroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        padding: const EdgeInsets.symmetric(horizontal: defaultPadding),
        child: SafeArea(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Padding(
                padding: EdgeInsets.symmetric(vertical: defaultPadding),
                child: Header(),
              ),
              const SizedBox(height: 5),
              Container(
                margin: const EdgeInsets.all(5),
                padding: const EdgeInsets.all(defaultPadding),
                decoration: const BoxDecoration(
                  color: secondaryColor,
                  borderRadius: BorderRadius.all(Radius.circular(10)),
                ),
                child: SizedBox(
                    width: MediaQuery.of(context).size.width,
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(0, 30, 0, 30),
                      child: Column(
                        children: <Widget>[
                          Text('Select Security Mode:'),
                          ListTile(
                            title: Text("Automatic"),
                            leading: Radio(
                              groupValue: val,
                              value: 1,
                              onChanged: (value) {
                                setState(() {
                                  val = value as int;
                                  auto = true;
                                });
                              },
                              activeColor: Colors.red,
                            ),
                          ),
                          ListTile(
                            title: Text("Manual(Remote Monitoring)"),
                            leading: Radio(
                              groupValue: val,
                              value: 3,
                              onChanged: (value) {
                                setState(() {
                                  val = value as int;
                                  auto = false;
                                });
                              },
                              activeColor: Colors.red,
                            ),
                          ),
                          auto ? _returnAutomatic() : _returnManual()
                        ],
                      ),
                    )),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
